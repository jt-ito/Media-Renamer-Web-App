﻿# PowerShell install-and-run
corepack enable
corepack prepare pnpm@latest --activate
Set-Location -Path "\server"
pnpm install --frozen-lockfile --prod
node dist/server.js
