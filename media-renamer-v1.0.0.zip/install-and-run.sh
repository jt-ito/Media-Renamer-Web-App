﻿#!/usr/bin/env sh
set -e

# This script is intended to run from the repo's `release/` folder.
# It will prefer a prebuilt `server/dist/server.js` if present and
# otherwise try to install runtime deps before starting the server.

## Resolve script directory and repository root so the script works when run
## from either the repo root or the `release/` folder.
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$BASE_DIR/.." && pwd)"

# Prefer the server directory at the repository root, but fall back to a
# server/ folder next to this script (in case the script is bundled inside release/).
if [ -d "$REPO_ROOT/server" ]; then
  SERVER_DIR="$REPO_ROOT/server"
else
  SERVER_DIR="$BASE_DIR/server"
fi

RELEASE_PREBUILT="$REPO_ROOT/release/server/server.js"

cd "$SERVER_DIR" 2>/dev/null || {
  echo "server directory not found at $SERVER_DIR" >&2
  if [ -f "$RELEASE_PREBUILT" ]; then
    echo "Starting packaged prebuilt server at $RELEASE_PREBUILT"
    node "$RELEASE_PREBUILT"
    exit 0
  fi
  exit 1
}

# If the server is already built under dist, start it
if [ -f dist/server.js ]; then
  echo "Found built server at server/dist/server.js — starting without install"
  node dist/server.js
  exit 0
fi

# If there is a prebuilt server.js in the server folder, prefer it (this
# is common when release bundles non-TS prebuilt code into server/).
if [ -f server.js ]; then
  echo "Found prebuilt server at server/server.js — starting"
  node server.js
  exit 0
fi

# Ensure we have pnpm (via corepack or installed pnpm) or fall back to installing pnpm via npm.
if command -v corepack >/dev/null 2>&1; then
  corepack enable
  corepack prepare pnpm@latest --activate
elif command -v pnpm >/dev/null 2>&1; then
  echo "pnpm found - using existing pnpm"
else
  if command -v npm >/dev/null 2>&1; then
    echo "pnpm not found - installing pnpm via npm (may require sudo)"
    npm install -g pnpm
  else
    echo "No npm found. Attempting to install Node 18 (Debian/Ubuntu) via NodeSource script (requires sudo)."
    # Try to bootstrap Node.js on Debian/Ubuntu systems using NodeSource script.
    # This requires curl and sudo. If the target system is not Debian-based,
    # this may fail and a manual install will be required.
    if command -v curl >/dev/null 2>&1 && command -v sudo >/dev/null 2>&1; then
      echo "Running NodeSource setup script (may prompt for sudo password)..."
      curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
      sudo apt-get install -y nodejs build-essential
    else
      echo "curl or sudo missing; cannot automatically install Node. Please install Node.js (>=16.10) or run via Docker." >&2
      echo "ERROR: neither corepack nor pnpm nor npm found. Install Node.js (>=16.10) or run via Docker." >&2
      exit 1
    fi
    # After attempting to install Node, ensure npm exists and install pnpm.
    if command -v npm >/dev/null 2>&1; then
      npm install -g pnpm
    else
      echo "npm still not found after attempted Node install; aborting." >&2
      exit 1
    fi
  fi
fi

## NOTE: If you copied this file from a Windows machine and see
## "#!/usr/bin/env: No such file or directory" when running
## ./install-and-run.sh, first convert the file to LF line endings on
## the target machine (run `sed -i 's/\r$//' install-and-run.sh` or
## `dos2unix install-and-run.sh`) before making it executable.

# If dist isn't present we need build tools (devDependencies). Install
# full dependencies (not --prod) and run the build. If a lockfile exists
# prefer frozen mode to keep reproducible installs.
if [ -f dist/server.js ]; then
  echo "dist/server.js present — starting"
  node dist/server.js
  exit 0
fi

# If we don't have a tsconfig.json (sources not present) but a prebuilt
# server is packaged inside release/, use that instead of attempting to build.
if [ ! -f tsconfig.json ]; then
  if [ -f "$BASE_DIR/release/server/server.js" ]; then
    echo "tsconfig.json missing; starting packaged prebuilt server at release/server/server.js"
    node "$BASE_DIR/release/server/server.js"
    exit 0
  fi
  echo "tsconfig.json missing and no prebuilt server found; cannot build from source." >&2
  exit 1
fi

echo "Building server from source (dist missing). Installing dev deps and building..."
if [ -f pnpm-lock.yaml ] || [ -f pnpm-lock.yml ]; then
  echo "pnpm lockfile found - installing with --frozen-lockfile"
  pnpm install --frozen-lockfile
else
  echo "pnpm lockfile missing - installing without --frozen-lockfile"
  pnpm install
fi

echo "Running build: prefer local ./node_modules/.bin/tsc, fallback to pnpm exec or npx"
if [ -x ./node_modules/.bin/tsc ]; then
  echo "Using local node_modules/.bin/tsc"
  ./node_modules/.bin/tsc -p tsconfig.json
elif command -v pnpm >/dev/null 2>&1; then
  echo "Using pnpm exec tsc"
  pnpm exec tsc -p tsconfig.json
elif command -v npx >/dev/null 2>&1; then
  echo "Using npx tsc"
  npx tsc -p tsconfig.json
else
  echo "ERROR: no TypeScript compiler found (local node_modules/.bin/tsc, pnpm or npx)." >&2
  exit 1
fi

echo "Starting server"
node dist/server.js
