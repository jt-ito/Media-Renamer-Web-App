// server/src/server.ts
import Fastify from 'fastify';
import cors from '@fastify/cors';
import fstatic from '@fastify/static';
import fg from 'fast-glob';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { loadLibraries, saveLibraries } from './config.js';
import { getLogs, log } from './logging.js';
import { inferFromPath } from './parse.js';
import { searchTVDB, getEpisodeByAiredOrder, mapAbsoluteToAired, invalidateTVDBToken, getSeries } from './tvdb.js';
import { planEpisode, planMovie, applyPlans } from './renamer.js';
import { initApproved, isApproved, markApproved, approvedList, unapproveLast } from './approved.js';
import { loadSettings, saveSettings } from './settings.js';
// ESM-safe __dirname/__filename
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
async function registerWeb(app) {
    const STATIC_ROOT = process.env.STATIC_ROOT
        ? path.resolve(process.env.STATIC_ROOT)
        : path.resolve(__dirname, '../web/dist'); // adjust to match where dist actually lives
    if (!app._staticMounted) {
        await app.register(fstatic, { root: STATIC_ROOT, prefix: '/' });
        app._staticMounted = true;
        app.log.info(`@fastify/static mounted at ${STATIC_ROOT}`);
    }
    if (!app._rootRegistered) {
        app._rootRegistered = true;
        app.get('/', async (_req, reply) => reply.sendFile('index.html'));
    }
    if (!app._spaFallbackRegistered) {
        app._spaFallbackRegistered = true;
        app.setNotFoundHandler((req, reply) => {
            const accept = String(req.headers.accept || '');
            const isHtml = accept.includes('text/html');
            const isGet = req.method === 'GET';
            const isApi = req.url.startsWith('/api/');
            if (isGet && isHtml && !isApi) {
                return reply.sendFile('index.html');
            }
            return reply.status(404).send({ message: 'Not Found' });
        });
    }
}
async function bootstrap() {
    const app = Fastify({ logger: false });
    // Normalize year inputs (string/number) into a safe number or undefined
    function parseYear(y) {
        if (y == null)
            return undefined;
        // avoid literal strings like 'undefined' or empty
        if (typeof y === 'string' && (!y.trim() || y.trim().toLowerCase() === 'undefined'))
            return undefined;
        const n = Number(y);
        return Number.isFinite(n) && Number.isInteger(n) && n > 0 ? n : undefined;
    }
    // Static + root + SPA fallback
    await registerWeb(app);
    // Optional CORS (idempotent)
    if (process.env.ENABLE_CORS === '1' && !app._corsRegistered) {
        await app.register(cors, { origin: true });
        app._corsRegistered = true;
        app.log?.info?.('CORS enabled');
    }
    // Approvals registry
    initApproved();
    // guessit support removed; rely on builtin parsing
    const idFromPath = (p) => crypto.createHash('sha1').update(p).digest('hex');
    // When a file is approved, also try to find sibling files in the same
    // directory that look like the same series/season/episode but differ only
    // by an appended episode title (for example: "Citrus - S01E01" vs "Citrus - S01E01 - love affair!?")
    function escapeRegex(s) {
        return String(s).replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
    }
    function markSiblingApprovals(original, size, tvdbId, type) {
        try {
            const dir = path.dirname(original);
            const base = path.basename(original);
            const inferred = inferFromPath(original);
            if (!inferred || inferred.kind !== 'series' || inferred.season == null)
                return;
            const season = inferred.season;
            const episode = (inferred.episodes && inferred.episodes[0]) || inferred.episode_number || (inferred.absolute && inferred.absolute[0]);
            if (episode == null)
                return;
            // Build a loose regex that matches filenames starting with the same series
            // and the same SxxEyy code, ignoring trailing " - title" differences.
            const titleRoot = inferred.title || '';
            const paddedS = String(season).padStart(2, '0');
            const paddedE = String(episode).padStart(2, '0');
            const escTitle = escapeRegex(titleRoot);
            const re = new RegExp(`^\\s*${escTitle}\\s*-\\s*S${paddedS}E${paddedE}(?:\\b|\\s|\\-).*$`, 'i');
            // Scan directory for matching files
            const files = fs.existsSync(dir) ? fs.readdirSync(dir) : [];
            for (const f of files) {
                try {
                    const full = path.join(dir, f);
                    if (full === original)
                        continue;
                    const st = fs.statSync(full);
                    if (!st.isFile())
                        continue;
                    if (isApproved(full, st.size))
                        continue;
                    const nameNoExt = path.basename(f, path.extname(f));
                    if (re.test(nameNoExt)) {
                        markApproved(full, st.size, tvdbId, type, '');
                        log('info', `AUTO_APPROVE_SIBLING | tvdbId=${tvdbId} | type=${type} | source="${full}" matched to "${original}"`);
                    }
                }
                catch (e) { /* ignore per-file errors */ }
            }
        }
        catch (e) {
            // best-effort only
        }
    }
    // Normalize plans for preview responses: call the canonical finalizer
    // used during apply so preview paths exactly match the real output.
    async function normalizePlansForPreview(plans) {
        try {
            const { finalizePlan } = await import('./renamer.js');
            for (const p of plans) {
                try {
                    if (!p)
                        continue;
                    // finalizePlan is safe to call during dry-run and will perform
                    // the same uniquePath/metadataTitle/year insertion and folder
                    // adjustments that applyPlans uses when creating files.
                    try {
                        await finalizePlan(p);
                    }
                    catch (e) {
                        // Ignore per-plan finalization errors; preserve best-effort behavior
                    }
                }
                catch (e) { /* per-plan best-effort */ }
            }
        }
        catch (e) { /* ignore normalize errors */ }
        return plans;
    }
    // Ensure any plan missing a year attempts a TVDB fetch when a tvdbId is present.
    async function ensurePlanYears(plans) {
        try {
            for (const p of plans) {
                try {
                    if (!p || !p.meta)
                        continue;
                    if (p.meta.type === 'series' && !p.meta.year && p.meta.tvdbId) {
                        try {
                            const s = await getSeries(Number(p.meta.tvdbId));
                            const maybe = s?.firstAired || s?.firstAiredAt || s?.releaseDate || s?.released || s?.firstAiredDate
                                || (s?.attributes && (s.attributes.firstAired || s.attributes.firstAiredAt || s.attributes.releaseDate || s.attributes.released || s.attributes.firstAiredDate))
                                || (s?.data && (s.data.firstAired || s.data.firstAiredAt || s.data.releaseDate || s.data.released || s.data.firstAiredDate));
                            const y = maybe ? String(maybe).slice(0, 4) : undefined;
                            if (y && /^\d{4}$/.test(y))
                                p.meta.year = Number(y);
                        }
                        catch (e) { /* ignore per-plan */ }
                    }
                }
                catch (e) { /* per-plan best-effort */ }
            }
        }
        catch (e) { }
        return plans;
    }
    // API routes
    // Health endpoint for production readiness checks
    app.get('/health', async () => {
        return { status: 'ok', uptime: process.uptime(), now: Date.now() };
    });
    // Graceful shutdown on signals
    process.on('SIGINT', async () => {
        try {
            app.log?.info?.('SIGINT received, closing server');
        }
        catch { }
        try {
            await app.close();
        }
        catch { }
        process.exit(0);
    });
    process.on('SIGTERM', async () => {
        try {
            app.log?.info?.('SIGTERM received, closing server');
        }
        catch { }
        try {
            await app.close();
        }
        catch { }
        process.exit(0);
    });
    app.get('/api/libraries', async () => {
        try {
            const libs = loadLibraries();
            log('info', `Returned ${libs.length} libraries`);
            return libs;
        }
        catch (e) {
            log('error', `Failed to load libraries: ${e?.message ?? String(e)}`);
            throw e;
        }
    });
    app.post('/api/libraries', async (req, reply) => {
        try {
            const body = req.body;
            saveLibraries(body);
            log('info', `Libraries saved: ${body.map(b => `${b.name}(${b.type})`).join(', ')}`);
            reply.send({ ok: true });
        }
        catch (e) {
            log('error', `Failed to save libraries: ${e?.message ?? String(e)}`);
            reply.status(500).send({ error: 'Failed to save libraries' });
        }
    });
    app.get('/api/approved', async () => approvedList());
    app.post('/api/scan', async (req, reply) => {
        try {
            const { libraryId } = req.body;
            const q = req.query || {};
            const offset = Math.max(0, Number(q.offset ?? 0));
            const limit = Math.min(500, Math.max(10, Number(q.limit ?? 100)));
            const libs = loadLibraries();
            const lib = libs.find(l => l.id === libraryId);
            if (!lib) {
                log('warn', `Scan requested for unknown library ${libraryId}`);
                reply.status(404).send({ error: 'Library not found' });
                return;
            }
            const patterns = ['**/*.mkv', '**/*.mp4', '**/*.avi', '**/*.mov', '**/*.m4v'];
            const files = await fg(patterns, { cwd: lib.inputRoot, absolute: true, suppressErrors: true });
            const candidates = [];
            for (const f of files) {
                const st = fs.statSync(f);
                if (!st.isFile())
                    continue;
                if (isApproved(f, st.size))
                    continue;
                candidates.push({ path: f, size: st.size });
            }
            const slice = candidates.slice(offset, offset + limit);
            // Use local inference heuristic
            const items = await Promise.all(slice.map(async ({ path: f, size }) => {
                const ext = path.extname(f);
                let inferred = inferFromPath(f);
                try {
                    // Use local inference only (external GuessIt removed)
                    inferred = { ...inferred, confidence: Math.max(inferred.confidence || 0, 6) };
                }
                catch (e) {
                    // ignore
                }
                return { id: idFromPath(f), path: f, size, ext, libraryId, inferred };
            }));
            return {
                items,
                total: candidates.length,
                nextOffset: offset + items.length,
                hasMore: offset + items.length < candidates.length
            };
        }
        catch (e) {
            log('error', `Scan failed: ${e?.message ?? String(e)}`);
            reply.status(500).send({ error: 'Scan failed' });
        }
    });
    app.get('/api/search', async (req) => {
        const q = req.query;
        const type = q.type;
        const query = q.q;
        const year = q.year ? Number(q.year) : undefined;
        const settings = loadSettings();
        const key = process.env.TVDB_API_KEY || settings.tvdbKey;
        if (!key) {
            // No API key configured; return empty result with a warning so frontend can skip calling TVDB.
            return { data: [], warning: 'TVDB API key not configured' };
        }
        const data = await searchTVDB(type, query, year);
        return { data };
    });
    // Parsing endpoint: returns local heuristic inference for a given path
    app.post('/api/guessit-parse', async (req, reply) => {
        try {
            const { path: p } = req.body;
            if (!p)
                return reply.status(400).send({ error: 'missing path' });
            const inferred = inferFromPath(p);
            return { inferred };
        }
        catch (e) {
            const inferred = inferFromPath(req.body?.path || '');
            return { inferred, error: e?.message ?? 'parse failed' };
        }
    });
    app.get('/api/episode-title', async (req) => {
        const q = req.query;
        const sId = Number(q.seriesId);
        const season = Number(q.season);
        const ep = Number(q.episode);
        const data = await getEpisodeByAiredOrder(sId, season, ep);
        return { title: data?.name || data?.episodeName || null };
    });
    app.get('/api/map-absolute', async (req) => {
        const q = req.query;
        const sId = Number(q.seriesId);
        const abs = String(q.abs || '').split(',').map((n) => Number(n)).filter(Boolean);
        const data = await mapAbsoluteToAired(sId, abs);
        return { data };
    });
    app.post('/api/preview', async (req, reply) => {
        try {
            const { libraryId, selections } = req.body;
            const libs = loadLibraries();
            const lib = libs.find(l => l.id === libraryId);
            // If the client didn't include an episodeTitle, try fetching it from TVDB so
            // planned filenames include the title shown in the UI.
            async function fetchEpisodeTitleIfNeeded(seriesId, season, eps) {
                if (!seriesId)
                    return null;
                const ep = eps && eps.length ? eps[0] : 1;
                try {
                    // First, try to look up by the provided season/episode (aired order)
                    const data = await getEpisodeByAiredOrder(Number(seriesId), Number(season ?? 1), Number(ep));
                    if (data)
                        return data?.name || data?.episodeName || null;
                    // If not found, maybe the provided episode number was an absolute number.
                    // Ask TVDB to map absolute->aired and use the mapped result if available.
                    try {
                        const mapped = await mapAbsoluteToAired(Number(seriesId), eps && eps.length ? eps : [ep]);
                        if (Array.isArray(mapped) && mapped.length && mapped[0]) {
                            return mapped[0].title || null;
                        }
                    }
                    catch (e) {
                        // ignore mapping errors
                    }
                    return null;
                }
                catch (e) {
                    return null;
                }
            }
            const plans = await Promise.all(selections.map(async (sel) => {
                if (sel.type === 'movie') {
                    // Build match candidate and prefer provided year
                    let match = { id: sel.match.id, name: sel.match.name, year: parseYear(sel.match.year), type: 'movie' };
                    if (!match.year && sel.match.year)
                        match.year = sel.match.year;
                    // If the client didn't provide a concrete TVDB id, try a search.
                    if (!match.id) {
                        try {
                            const results = await searchTVDB('movie', sel.match.name, sel.match.year);
                            if (Array.isArray(results) && results.length) {
                                match = results[0];
                            }
                        }
                        catch (e) { }
                    }
                    // If we have a TVDB id, fetch canonical info (name/year) so preview shows
                    // the TVDB-updated metadata instead of only the local parsed values.
                    if (match.id) {
                        try {
                            const s = await getSeries(Number(match.id));
                            if (s) {
                                // Prefer TVDB's canonical name when available
                                if (s.name)
                                    match.name = s.name;
                                const maybe = s?.firstAired || s?.firstAiredAt || s?.releaseDate || s?.released || s?.firstAiredDate
                                    || (s?.attributes && (s.attributes.firstAired || s.attributes.firstAiredAt || s.attributes.releaseDate || s.attributes.released || s.attributes.firstAiredDate))
                                    || (s?.data && (s.data.firstAired || s.data.firstAiredAt || s.data.releaseDate || s.data.released || s.data.firstAiredDate));
                                const y = maybe ? String(maybe).slice(0, 4) : undefined;
                                if (y && /^\d{4}$/.test(y))
                                    match.year = Number(y);
                            }
                        }
                        catch (e) { }
                    }
                    try {
                        log('debug', `preview: planning movie for ${sel.item.path} with match=${JSON.stringify(match)}`);
                    }
                    catch { }
                    // Ensure item has an ext when previewing (clients may send only path)
                    // Ensure extension is a safe string (avoid literal 'undefined' showing up)
                    sel.item.ext = sel.item.ext ? String(sel.item.ext) : path.extname(sel.item.path) || '';
                    if (sel.item.ext && !sel.item.ext.startsWith('.'))
                        sel.item.ext = '.' + sel.item.ext;
                    try {
                        log('debug', `preview: item.ext='${sel.item.ext}' path='${sel.item.path}'`);
                    }
                    catch { }
                    let pm = planMovie(sel.item, lib, match);
                    try {
                        log('debug', `preview: planned movie to=${pm.to}`);
                    }
                    catch { }
                    // Ensure plan meta has a concrete year before finalizing so finalizePlan
                    // can insert the year into metadataTitle/output when possible.
                    try {
                        if (pm && pm.meta && !pm.meta.year && match.year)
                            pm.meta.year = parseYear(match.year);
                    }
                    catch (e) { }
                    // Finalize movie plan so preview reflects the same canonicalization
                    // (unique path, metadataTitle and year derivation) as apply.
                    try {
                        const { finalizePlan } = await import('./renamer.js');
                        await finalizePlan(pm);
                    }
                    catch (e) { }
                    if (pm && pm.meta && !pm.meta.year && pm.meta.output) {
                        const m = String(pm.meta.output).match(/\((\d{4})\)/);
                        if (m)
                            pm.meta.year = Number(m[1]);
                    }
                    return pm;
                }
                // SERIES
                const season = sel.season ?? 1;
                const eps = sel.episodes && sel.episodes.length ? sel.episodes : [1];
                // episode title: prefer selection -> inferred -> TVDB -> local parse
                let title = sel.episodeTitle;
                if (!title && sel.item && sel.item.inferred) {
                    const infAny = sel.item.inferred;
                    if (infAny.episode_title)
                        title = infAny.episode_title;
                }
                if (!title)
                    title = await fetchEpisodeTitleIfNeeded(sel.match.id, season, eps);
                if (!title) {
                    try {
                        const local = inferFromPath(sel.item.path);
                        if (local && local.episode_title)
                            title = local.episode_title;
                    }
                    catch (e) { }
                }
                let match = { id: sel.match.id, name: sel.match.name, year: parseYear(sel.match.year), type: 'series' };
                if (!match.id) {
                    if (!match.year && sel.match.year)
                        match.year = sel.match.year;
                    try {
                        const results = await searchTVDB('series', sel.match.name, sel.match.year);
                        if (Array.isArray(results) && results.length) {
                            match = results[0];
                            if (!match.year)
                                match.year = sel.match.year ?? undefined;
                        }
                    }
                    catch (e) { }
                }
                if (!match.year && match.id) {
                    try {
                        const s = await getSeries(Number(match.id));
                        const maybe = s?.firstAired || s?.firstAiredAt || s?.releaseDate || s?.released || s?.firstAiredDate
                            || (s?.attributes && (s.attributes.firstAired || s.attributes.firstAiredAt || s.attributes.releaseDate || s.attributes.released || s.attributes.firstAiredDate))
                            || (s?.data && (s.data.firstAired || s.data.firstAiredAt || s.data.releaseDate || s.data.released || s.data.firstAiredDate));
                        const y = maybe ? String(maybe).slice(0, 4) : undefined;
                        if (y && /^\d{4}$/.test(y))
                            match.year = Number(y);
                    }
                    catch (e) { }
                }
                // Also prefer TVDB's canonical series name when we have an id
                if (match.id) {
                    try {
                        const s2 = await getSeries(Number(match.id));
                        if (s2 && s2.name)
                            match.name = s2.name;
                    }
                    catch (e) { }
                }
                if (!match.year)
                    match.year = sel.match?.year ?? undefined;
                try {
                    log('debug', `preview: planning episode for ${sel.item.path} with match=${JSON.stringify(match)} season=${season} eps=${eps.join(',')} title=${title}`);
                }
                catch { }
                sel.item.ext = sel.item.ext ? String(sel.item.ext) : path.extname(sel.item.path) || '';
                if (sel.item.ext && !sel.item.ext.startsWith('.'))
                    sel.item.ext = '.' + sel.item.ext;
                try {
                    log('debug', `preview: item.ext='${sel.item.ext}' path='${sel.item.path}' season=${season} eps=${eps.join(',')}`);
                }
                catch { }
                const pe = planEpisode(sel.item, lib, match, season, eps, title);
                try {
                    log('debug', `preview: planned episode to=${pe.to}`);
                }
                catch { }
                try {
                    // Ensure year present on plan meta before finalization so finalizePlan
                    // can insert it into metadataTitle/output.
                    if (pe && pe.meta && !pe.meta.year && match.year)
                        pe.meta.year = parseYear(match.year);
                }
                catch (e) { }
                try {
                    const { finalizePlan } = await import('./renamer.js');
                    await finalizePlan(pe);
                }
                catch (e) { }
                if (pe && pe.meta && !pe.meta.year && pe.meta.output) {
                    const m = String(pe.meta.output).match(/\((\d{4})\)/);
                    if (m)
                        pe.meta.year = Number(m[1]);
                }
                return pe;
            }));
            // Normalize all plans for preview so metadataTitle/output include inserted year
            try {
                await ensurePlanYears(plans);
                await normalizePlansForPreview(plans);
            }
            catch (e) { }
            return { plans };
        }
        catch (e) {
            log('error', `Preview failed: ${e?.message ?? String(e)}`);
            reply.status(500).send({ error: 'Preview failed' });
        }
    });
    // Auto-preview using local parsing heuristics (no TVDB lookup).
    app.post('/api/auto-preview', async (req, reply) => {
        try {
            const { libraryId, item, minConfidence = 3 } = req.body;
            const libs = loadLibraries();
            const lib = libs.find(l => l.id === libraryId);
            if (!lib) {
                log('warn', `Auto-preview requested for unknown library ${libraryId}`);
                reply.status(404).send({ error: 'Library not found' });
                return;
            }
            // Prefer any inference the client already attached (from scan/guessit) so
            // we don't lose guessed episode titles. Fall back to local inference when
            // no client-provided inferred object exists.
            const inferred = item?.inferred ?? inferFromPath(item.path);
            // require a minimal confidence to auto-generate plans
            if (!inferred || inferred.confidence < Number(minConfidence)) {
                return { plans: [], inferred };
            }
            // Build a fake MatchCandidate from inferred data
            if (inferred.kind === 'movie' && inferred.title) {
                let cand = { id: 0, name: inferred.title, year: parseYear(inferred.year), type: 'movie' };
                try {
                    const results = await searchTVDB('movie', inferred.title || '', inferred.year);
                    if (Array.isArray(results) && results.length)
                        cand = results[0];
                    // preserve inferred year if TVDB result lacks it
                    if (!cand.year && inferred.year)
                        cand.year = inferred.year;
                }
                catch (e) { }
                // If we have a TVDB id, fetch canonical info so preview reflects TVDB metadata
                if (cand.id) {
                    try {
                        const s = await getSeries(Number(cand.id));
                        if (s && s.name)
                            cand.name = s.name;
                        const maybe = s?.firstAired || s?.firstAiredAt || s?.releaseDate || s?.released || s?.firstAiredDate
                            || (s?.attributes && (s.attributes.firstAired || s.attributes.firstAiredAt || s.attributes.releaseDate || s.attributes.released || s.attributes.firstAiredDate))
                            || (s?.data && (s.data.firstAired || s.data.firstAiredAt || s.data.releaseDate || s.data.released || s.data.firstAiredDate));
                        const y = maybe ? String(maybe).slice(0, 4) : undefined;
                        if (y && /^\d{4}$/.test(y))
                            cand.year = Number(y);
                    }
                    catch (e) { }
                }
                if (!item.ext)
                    item.ext = path.extname(item.path) || '';
                try {
                    log('debug', `auto-preview movie: item.ext='${item.ext}' path='${item.path}'`);
                }
                catch { }
                const plan = planMovie(item, lib, cand);
                try {
                    // Ensure plan meta has the candidate year before finalization
                    if (plan && plan.meta && !plan.meta.year && cand && cand.year)
                        plan.meta.year = parseYear(cand.year);
                    const { finalizePlan } = await import('./renamer.js');
                    await finalizePlan(plan);
                }
                catch (e) { }
                try {
                    await ensurePlanYears([plan]);
                }
                catch (e) { }
                await normalizePlansForPreview([plan]);
                return { plans: [plan], inferred };
            }
            if (inferred.kind === 'series' && inferred.title) {
                let cand = { id: 0, name: inferred.title, year: parseYear(inferred.year), type: 'series' };
                const season = inferred.season ?? 1;
                const eps = inferred.episodes && inferred.episodes.length ? inferred.episodes : (inferred.absolute && inferred.absolute.length ? inferred.absolute : [1]);
                // Prefer any episode title already present on the inferred object.
                // If not present, we'll rely on TVDB lookups when a concrete series id is known.
                let title = undefined;
                const infAny = inferred;
                if (infAny?.episode_title) {
                    title = infAny.episode_title;
                }
                try {
                    const results = await searchTVDB('series', inferred.title || '', inferred.year);
                    if (Array.isArray(results) && results.length)
                        cand = results[0];
                    // preserve inferred year if TVDB result lacks it
                    if (!cand.year && inferred.year)
                        cand.year = inferred.year;
                }
                catch (e) { }
                // If TVDB provided an id, fetch canonical series info to enrich name/year
                if (cand.id) {
                    try {
                        const s = await getSeries(Number(cand.id));
                        if (s && s.name)
                            cand.name = s.name;
                        const maybe = s?.firstAired || s?.firstAiredAt || s?.releaseDate || s?.released || s?.firstAiredDate
                            || (s?.attributes && (s.attributes.firstAired || s.attributes.firstAiredAt || s.attributes.releaseDate || s.attributes.released || s.attributes.firstAiredDate))
                            || (s?.data && (s.data.firstAired || s.data.firstAiredAt || s.data.releaseDate || s.data.released || s.data.firstAiredDate));
                        const y = maybe ? String(maybe).slice(0, 4) : undefined;
                        if (y && /^\d{4}$/.test(y))
                            cand.year = Number(y);
                    }
                    catch (e) { }
                }
                try {
                    if (!item.ext)
                        item.ext = path.extname(item.path) || '';
                    log('debug', `auto-preview episode: item.ext='${item.ext}' path='${item.path}' season=${season} eps=${eps.join(',')}`);
                }
                catch { }
                const plan = planEpisode(item, lib, cand, season, eps, title);
                try {
                    // Ensure plan meta has the candidate year before finalization
                    if (plan && plan.meta && !plan.meta.year && cand && cand.year)
                        plan.meta.year = parseYear(cand.year);
                    const { finalizePlan } = await import('./renamer.js');
                    await finalizePlan(plan);
                }
                catch (e) { }
                await normalizePlansForPreview([plan]);
                return { plans: [plan], inferred };
            }
            try {
                await ensurePlanYears([]);
            }
            catch (e) { }
            await normalizePlansForPreview([]);
            return { plans: [], inferred };
        }
        catch (e) {
            log('error', `Auto preview failed: ${e?.message ?? String(e)}`);
            reply.status(500).send({ error: 'Auto preview failed' });
        }
    });
    app.post('/api/rename', async (req, reply) => {
        try {
            const { plans, libraryId } = req.body;
            const lib = loadLibraries().find(l => l.id === libraryId);
            plans.forEach(p => (p.dryRun = false));
            const { results } = applyPlans(plans, !!lib.allowCopyFallback);
            for (const p of plans) {
                try {
                    const st = fs.statSync(p.from);
                    markApproved(p.from, st.size, p.meta.tvdbId, p.meta.type, p.to);
                    // Also try to auto-mark sibling metadata files that represent the same ep
                    try {
                        markSiblingApprovals(p.from, st.size, p.meta.tvdbId, p.meta.type);
                    }
                    catch (e) { }
                    log('info', `APPROVED | tvdbId=${p.meta.tvdbId} | type=${p.meta.type} | output="${p.to}" | source="${p.from}"`);
                }
                catch (e) {
                    log('warn', `Approval mark failed for ${p.from}: ${e.message}`);
                }
            }
            reply.send({ ok: true, count: results.length });
        }
        catch (e) {
            log('error', `Rename failed: ${e?.message ?? String(e)}`);
            reply.status(500).send({ error: 'Rename failed' });
        }
    });
    // Approve manually (persist TVDB id and type for a file without performing rename)
    app.post('/api/approve-manual', async (req, reply) => {
        try {
            const { libraryId, path: filePath, tvdbId, type } = req.body;
            if (!filePath)
                return reply.status(400).send({ error: 'missing path' });
            const libs = loadLibraries();
            const lib = libs.find(l => l.id === libraryId);
            // get size
            const st = fs.statSync(filePath);
            // output is left blank as no rename performed
            markApproved(filePath, st.size, Number(tvdbId) || 0, type, '');
            try {
                markSiblingApprovals(filePath, st.size, Number(tvdbId) || 0, type);
            }
            catch (e) { }
            log('info', `MANUAL_APPROVE | tvdbId=${tvdbId} | type=${type} | source="${filePath}"`);
            return { ok: true };
        }
        catch (e) {
            log('error', `Manual approve failed: ${e?.message ?? String(e)}`);
            reply.status(500).send({ error: 'Manual approve failed' });
        }
    });
    // Remove last N approved entries (undo)
    app.post('/api/unapprove-last', async (req, reply) => {
        try {
            const { n } = req.body;
            const count = Math.max(0, Number(n ?? 10));
            // call into approved module
            const removed = unapproveLast(count);
            log('info', `UNAPPROVE_LAST | removed=${removed.length}`);
            return { removed };
        }
        catch (e) {
            log('error', `Unapprove last failed: ${e?.message ?? String(e)}`);
            reply.status(500).send({ error: 'Unapprove failed' });
        }
    });
    app.get('/api/settings', async () => {
        try {
            const s = loadSettings();
            log('info', 'Settings fetched');
            return s;
        }
        catch (e) {
            log('error', `Failed to load settings: ${e?.message ?? String(e)}`);
            return {};
        }
    });
    app.post('/api/settings', async (req, reply) => {
        try {
            const body = req.body;
            const current = loadSettings();
            const next = { ...current, ...body };
            // Determine the previous (effective) key and the new key. Treat empty/null as "no key".
            const prevKey = (process.env.TVDB_API_KEY && String(process.env.TVDB_API_KEY)) || (current.tvdbKey && String(current.tvdbKey)) || '';
            const newKey = next.tvdbKey != null ? String(next.tvdbKey) : '';
            // Persist merged settings first (we want saves to always persist)
            const prevSettings = loadSettings();
            saveSettings(next);
            // guessit removed; nothing to apply
            // If the user cleared the key, immediately remove the active env var and invalidate token.
            if (!newKey && prevKey) {
                delete process.env.TVDB_API_KEY;
                invalidateTVDBToken();
                log('info', 'TVDB API key removed by user');
            }
            else if (newKey) {
                // If there was already a non-empty previous key, require the user to explicitly
                // delete it first before activating a new value. This prevents accidental
                // switching and matches the requested delete-then-enter workflow.
                if (prevKey) {
                    // Do not activate the new key yet; inform via logs. The new key is stored in settings
                    // but won't be used until the user clears the key and saves (delete + save), then
                    // re-enters and saves.
                    log('info', 'New TVDB API key saved to settings but not activated because an existing key is present; clear the key and save to activate.');
                }
                else {
                    // No previous key -> activate new key immediately
                    process.env.TVDB_API_KEY = newKey;
                    invalidateTVDBToken();
                    log('info', 'TVDB API key activated');
                }
            }
            log('info', 'Settings saved');
            // If port changed in settings, inform caller that restart is required
            const prevPort = prevSettings.port || Number(process.env.PORT || 0);
            const newPort = next.port || Number(process.env.PORT || 0);
            const restartRequired = prevPort !== newPort;
            reply.send({ ok: true, restartRequired });
        }
        catch (e) {
            log('error', `Failed to save settings: ${e?.message ?? String(e)}`);
            reply.status(500).send({ error: 'Failed to save settings' });
        }
    });
    // SSE logs
    app.get('/api/logs/stream', async (req, reply) => {
        reply.raw.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            Connection: 'keep-alive'
        });
        let cursor = 0;
        const tick = () => {
            const entries = getLogs();
            if (cursor < entries.length) {
                for (let i = cursor; i < entries.length; i++) {
                    reply.raw.write(`event: log\ndata: ${JSON.stringify(entries[i])}\n\n`);
                }
                cursor = entries.length;
            }
        };
        const timer = setInterval(tick, 1000);
        req.raw.on('close', () => clearInterval(timer));
    });
    // Plain logs fetch (non-stream) used by UI
    app.get('/api/logs', async () => {
        try {
            return getLogs();
        }
        catch (e) {
            return [];
        }
    });
    // Get/set runtime log level for UI control
    app.get('/api/loglevel', async () => {
        try {
            const { getLogLevel } = await import('./logging.js');
            return { level: getLogLevel() };
        }
        catch (e) {
            return { level: 'info' };
        }
    });
    app.post('/api/loglevel', async (req, reply) => {
        try {
            const body = req.body;
            const lvl = (body && String(body.level || '').toLowerCase());
            if (!['info', 'warn', 'error', 'debug'].includes(lvl))
                return reply.status(400).send({ error: 'invalid level' });
            const { setLogLevel } = await import('./logging.js');
            setLogLevel(lvl);
            return { ok: true, level: lvl };
        }
        catch (e) {
            reply.status(500).send({ error: 'failed' });
        }
    });
    // Effective port: environment overrides persisted settings; otherwise use settings.port if set
    const persistedSettings = loadSettings();
    const envPort = Number(process.env.PORT || 0);
    const port = envPort || Number(persistedSettings.port || 0) || 8080;
    try {
        log('info', `Effective port: ${port} (envPort=${envPort || 'none'}, settings.port=${persistedSettings.port || 'none'})`);
    }
    catch { }
    app
        .listen({ port, host: '0.0.0.0' })
        .then(() => {
        log('info', `Server listening on ${port}`);
        try {
            console.info(`Server listening on ${port}`);
        }
        catch (e) { }
    })
        .catch(err => {
        app.log.error(err);
        process.exit(1);
    });
}
bootstrap().catch(err => {
    try {
        log('error', String(err));
    }
    catch { }
    process.exit(1);
});
